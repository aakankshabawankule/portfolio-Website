function addToCart(itemName, price, btn) {
  const quantity = parseInt(btn.previousElementSibling.value);
  const cartList = document.getElementById('cart-items');
  const total = quantity * price;

  const li = document.createElement('li');
  li.textContent = `${itemName} x ${quantity} = ₹${total}`;
  cartList.appendChild(li);

  totalAmount += total;
  updateTotal();
}

function updateTotal() {
  document.getElementById('total').textContent = `Total: ₹${totalAmount}`;
}

function clearCart() {
  document.getElementById('cart-items').innerHTML = '';
  totalAmount = 0;
  updateTotal();
}
